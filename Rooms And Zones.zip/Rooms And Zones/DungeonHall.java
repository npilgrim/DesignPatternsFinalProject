public class DungeonHall extends Room
{
	public DungeonHall()
	{
		super("The dungeon hallway. ",
			"You can barely see in here. The smell is absolutely " +
			"terrible! You hear screams up ahead!");		
	}
}
