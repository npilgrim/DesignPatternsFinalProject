public class ForestToGrounds extends Room
{
	public ForestToGrounds()
	{
		super("An exit to the castle grounds.",
			"The forest lies near. " +
			"You can see a castle in the distance and " + 
			"nearby lies the castle grounds.");		
	}
}
