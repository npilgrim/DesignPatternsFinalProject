public class ClearedWood extends Room
{
	public ClearedWood()
	{
		super("A cleared forest. ",
			"The trees in the area have been felled. " +
			"Something must have chopped them down.");		
	}
}
