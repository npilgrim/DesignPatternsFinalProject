public class CastleToDungeon extends Room
{
	public CastleToDungeon()
	{
		super("An exit to the dungeon. ",
			"A door descending into the shadows invites you. " +
			"You can barely stand the horrid stench emanating " +
			"from below");		
	}
}
