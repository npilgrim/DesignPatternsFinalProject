public class Hallway extends Room
{
	public Hallway()
	{
		super("A hallway. ",
			"You enter a stone hallway. Laterns adorn the walls." +
			" Your footsteps echo eerily throughout.");		
	}
}
