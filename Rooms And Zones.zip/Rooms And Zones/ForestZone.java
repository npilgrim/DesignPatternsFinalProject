public class ForestZone extends Zone
{
	public ForestZone()
	{
		super("Forest zone.", "A forrested zone in the middle of nowhere.");
	}
}
