public class Shield extends Armor
{
	private int health;
	
	public Shield()
	{
		health = 5;
		name = "large shield";
	}
	
	public int getHealth()
	{
		return health;
	}
}
