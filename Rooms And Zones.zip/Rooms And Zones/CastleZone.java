public class CastleZone extends Zone
{
	public CastleZone()
	{
		super("Castle.", "Inside the interior of the castle.");
	}
}
