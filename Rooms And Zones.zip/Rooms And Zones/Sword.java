public class Sword extends Weapon
{
	private int damage;
	
	public Sword()
	{
		damage = 10;
		name = "sword";
	}
	
	public int getDamage()
	{
		return damage;
	}
}
