public class CastleGroundsZone extends Zone
{
	public CastleGroundsZone()
	{
		super("Castle Grounds.", "Many gardens and courtyards to surround the castle.");
	}
}
