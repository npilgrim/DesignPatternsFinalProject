public class WoodedPath extends Room
{
	public WoodedPath()
	{
		super("A wooded path. ",
			"A frequently used path lies before you. Green trees " +
			"are everywhere. Might as well follow it.");		
	}
}
