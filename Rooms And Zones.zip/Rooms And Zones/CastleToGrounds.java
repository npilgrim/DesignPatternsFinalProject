public class CastleToGrounds extends Room
{
	public CastleToGrounds()
	{
		super("An exit to the castle grounds",
			"You stand in the main foyer of the castle. An " +
			"exit to the castle grounds is in this room. " + 
			"Somehow, you feel as if you should keep moving forward.");		
	}
}
