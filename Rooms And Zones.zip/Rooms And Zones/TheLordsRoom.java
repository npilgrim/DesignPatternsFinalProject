public class TheLordsRoom extends Room
{
	public TheLordsRoom()
	{
		super("The Lords Room. ",
			"A massive room lies infront of you. Everything " +
			"is colored purple and oversized. There is a " +
			"large bed in the center of the room and a wooden " +
			"chest is flush against the wall");		
	}
}
