public class Garden extends Room
{
	public Garden()
	{
		super("A beautiful garden. ",
			"Many colorful flowers grace the ground around you. " +
			"The petals bounce around in the wind.");		
	}
}
