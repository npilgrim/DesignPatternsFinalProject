public class NullRoom extends Room
{
	public NullRoom()
	{
		super("The Void.",
			"If you are seeing this, something went wrong!");
	}
}
