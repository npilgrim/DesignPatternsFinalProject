public class DungeonToCastle extends Room
{
	public DungeonToCastle()
	{
		super("An exit to the castle. ",
			"You are in the entrance to the dungeon. It is dimly lit " +
			"and smells of death. Should fear " +
			"overcome you, you can always retreat upwards.");		
	}
}
