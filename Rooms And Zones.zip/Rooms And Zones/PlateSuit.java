public class PlateSuit extends Armor
{
	private int health;
	
	public PlateSuit()
	{
		health = 10;
		name = "ornate plate suit";
	}
	
	public int getHealth()
	{
		return health;
	}
}
