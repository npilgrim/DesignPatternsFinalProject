public class HeavilyWooded extends Room
{
	public HeavilyWooded()
	{
		super("Heavily wooded area.",
			"Lots of trees up in here. Try not to hurt yourself.");		
	}
}
