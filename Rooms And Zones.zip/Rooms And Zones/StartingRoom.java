public class StartingRoom extends Room
{
	public StartingRoom()
	{
		super("A strange forest. ",
			"You have awoken in a strange forest. " +
			"You have no idea how you got here. " + 
			"Adventurer, your journey awaits.");		
	}
}
