public class Stick extends Weapon
{
	private int damage;
	
	public Stick()
	{
		damage = 4;
		name = "stick";
	}
	
	public int getDamage()
	{
		return damage;
	}
}
