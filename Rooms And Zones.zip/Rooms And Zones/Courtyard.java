public class Courtyard extends Room
{
	public Courtyard()
	{
		super("A courtyard. ",
			"You enter a part of the courtyard. " +
			"White walls surround you.");		
	}
}
