public enum Direction
{
	e, w, n, s, up, down
}
