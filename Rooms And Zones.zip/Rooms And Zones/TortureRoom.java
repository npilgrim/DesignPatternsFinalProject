public class TortureRoom extends Room
{
	public TortureRoom()
	{
		super("The torture room. ",
			"You have reached the end of the road, adventurer! " +
			"You must fight the madman who lies before you to " + 
			"survive the day!");		
	}
}
