public class GroundsToForest extends Room
{
	public GroundsToForest()
	{
		super("A neatly displayed property. ",
			"Before you is the royal gardens and courtyard. " +
			"A path back to the forest lies in the distance.");		
	}
}
