public class ChamberRoom extends Room
{
	public ChamberRoom()
	{
		super("A chamber room. ",
			"This room is frequently used for parties. " +
			"You sense this room is very important for " +
			"the owner");		
	}
}
