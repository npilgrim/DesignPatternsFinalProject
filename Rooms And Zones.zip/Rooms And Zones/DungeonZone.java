public class DungeonZone extends Zone
{
	public DungeonZone()
	{
		super("Dungeon.", "In the bowels of the dungeon.");
	}
}
