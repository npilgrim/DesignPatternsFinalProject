public class GroundsToCastle extends Room
{
	public GroundsToCastle()
	{
		super("Outside the castle. ",
			"The entrance to the castle stands before you. " +
			"A certain dread comes over you as you contemplate entering.");		
	}
}
