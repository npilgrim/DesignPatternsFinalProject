public class Phaser extends Weapon
{
	private int damage;
	
	public Phaser()
	{
		damage = 20;
		name = "phaser";
	}
	
	public int getDamage()
	{
		return damage;
	}
}
