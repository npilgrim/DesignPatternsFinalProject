public abstract class ItemDecorator
{
	
}
