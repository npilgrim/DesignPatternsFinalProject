public abstract class ArmorDecorator extends Armor
{
	public abstract String getName();
	public abstract int getHealth();
}
