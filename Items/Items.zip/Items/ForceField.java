public class ForceField extends Armor
{
	private int health;
	
	public ForceField()
	{
		health = 20;
		name = "glowing force field";
	}
	
	public int getHealth()
	{
		return health;
	}
}
