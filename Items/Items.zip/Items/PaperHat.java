public class PaperHat extends Armor
{
	private int health;
	
	public PaperHat()
	{
		health = 1;
		name = "silly paper hat";
	}
	
	public int getHealth()
	{
		return health;
	}
}
