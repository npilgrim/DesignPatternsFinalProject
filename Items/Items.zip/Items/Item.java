public interface Item
{		
	public String getName();
	public String getDescription();
	public String getType();
}
