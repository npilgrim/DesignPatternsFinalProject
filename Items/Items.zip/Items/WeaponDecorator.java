public abstract class WeaponDecorator extends Weapon
{
	public abstract String getName();
	public abstract int getDamage();
}
