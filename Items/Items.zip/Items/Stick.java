public class Stick extends Weapon
{
	private int damage;
	
	public Stick()
	{
		damage = 3;
		name = "stick";
	}
	
	public int getDamage()
	{
		return damage;
	}
}
