public class Staff extends Weapon
{
	private int damage;
	
	public Staff()
	{
		damage = 6;
		name = "staff";
	}
	
	public int getDamage()
	{
		return damage;
	}
}
